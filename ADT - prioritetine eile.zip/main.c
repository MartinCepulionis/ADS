#include <stdlib.h>
#include <stdio.h>
#include "priority_queue.h"

int main()
{
	int Error;
	prQueue_data_type Elementas;
	prQueue_priority_type Prioritetas;

	PriorityQueue q1 = create(&Error);
	PriorityQueue q2 = create(&Error);
	PriorityQueue q3 = create(&Error);

	insert(&q1,4,77);
	insert(&q1,3,35);


    print(q1);

	if(!removeElement(&q1,&Elementas,&Prioritetas))
    {
        printf("Istrintas elementas: %d %d\n",Elementas,Prioritetas);
    }
    else printf("Error code: %d \n",removeElement(&q1,&Elementas,&Prioritetas));

    if(!removeElement(&q1,&Elementas,&Prioritetas))
    {
        printf("Istrintas elementas: %d %d\n",Elementas,Prioritetas);
    }
    else printf("Error code: %d \n",removeElement(&q1,&Elementas,&Prioritetas));

    if(!removeElement(&q1,&Elementas,&Prioritetas))
    {
        printf("Istrintas elementas: %d %d\n",Elementas,Prioritetas);
    }
    else printf("Error code: %d \n",removeElement(&q1,&Elementas,&Prioritetas));




	return 0;
}
