#ifndef PRIORITY_QUEUE_TYPE_H
#define PRIORITY_QUEUE_TYPE_H

typedef int prQueue_data_type;
typedef int prQueue_priority_type;

#endif // PRIORITY_QUEUE_TYPE_H
