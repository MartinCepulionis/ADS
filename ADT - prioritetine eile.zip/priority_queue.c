#include <stdlib.h>
#include <stdio.h>
#include "priority_queue.h"
#include "priority_queue_type.h"

void print(PrQueue* Meta)
{
    printf("\n");
    if(isEmpty(Meta) == 0)
    {
        return 0;
    }
    else if(isEmpty(Meta) == 2)
    {
        return 2;
    }

    Element* Current = (Element*)malloc(sizeof(Element));
    Current = Meta->Head;
    int k = Meta->NrOfItems;
    while(k > 0)
    {
        printf("Value: %d Priority: %d \n",Current->Data, Current->Priority);
        Current = Current->Next;
        k--;
    }
    printf("\n");
}

Element* getNewItem(prQueue_data_type Value_Of_Element, prQueue_priority_type Priority_Of_Element, int* Error)
{
    Element *New = (Element*)malloc(sizeof(Element));

    if(New == NULL)
    {
        *Error = 1;
        return NULL;
    }

    New->Data = Value_Of_Element;
    New->Priority = Priority_Of_Element;
    New->Next = NULL;
    New->Prev = NULL;
    *Error = 0;
    return New;
}

PrQueue* create(int* Error)
{
    PrQueue* Meta = (PrQueue*)malloc(sizeof(PrQueue));

    if(Meta == NULL)
    {
        *Error = 1;
        return NULL;
    }

    Meta->NrOfItems = 0;
    Meta->Head = NULL;
    *Error = 0;
    return Meta;
}

int isFull(PrQueue* Queue)
{
    PrQueue* temp = NULL;
    temp = (PrQueue*)malloc(sizeof(PrQueue));

    if (temp == NULL)
        return 1;
    else
    {
        free(temp);
        return 0;
    }
}

int destroy(PriorityQueue* Queue)
{
    prQueue_data_type *Data;
    prQueue_priority_type *Priority;

    if((*Queue)== NULL)
    {
        return 1;
    }

    while((*Queue)->NrOfItems != 0)
    {
        removeElement((*Queue),&Data,&Priority);
    }

    free((*Queue));
    return 0;
}

int removeElement(PriorityQueue* Queue, prQueue_data_type *Data, prQueue_priority_type *Priority)
{
    if(isEmpty((*Queue)) == 1)
    {
        PrQueue* temp = (*Queue)->Head;
        Element* value=(*Queue)->Head->Data;
        Element* prior=(*Queue)->Head->Priority;
        *Data=value;
        *Priority=prior;
        (*Queue)->Head=(*Queue)->Head->Next;
        free(temp);
        (*Queue)->NrOfItems--;
        return 0;
    }
    else
    {
        return 1;
    }
}

int showElement(PrQueue* Queue, prQueue_data_type *Data, prQueue_priority_type *Priority)
{
    if(isEmpty(Queue) == 1)
    {
        PrQueue* temp = Queue->Head;
        Element* value=Queue->Head->Data;
        Element* prior=Queue->Head->Priority;
        *Data=value;
        *Priority=prior;
        return 0;
    }
    else
    {
        return 1;
    }
}

int isEmpty(PrQueue* Meta)
{
    if(Meta == NULL)
    {
        return 2;
    }
    if(Meta->NrOfItems == 0)
    {
        return 0;
    }
    else
        return 1;
}

int insert(PriorityQueue* Meta, prQueue_data_type Value, prQueue_priority_type Priority)
{
    if((*Meta) == NULL)
    {
        return 1;
    }

    int Error;

    Element* New = getNewItem(Value,Priority,&Error);

    if(Error == 1)
    {
        return 2;
    }

    if((*Meta)->Head == NULL)
    {
        (*Meta)->Head = New;
        (*Meta)->NrOfItems++;
        return 0;
    }

    Element* Current = (*Meta)->Head;
    if(New->Priority > Current->Priority)
    {
        (*Meta)->Head = New;
        New->Next = Current;
        Current->Prev = New;
        (*Meta)->NrOfItems++;
        return 0;
    }
    if((*Meta)->NrOfItems == 1)
    {
        Current->Next = New;
        New->Prev = Current;
        (*Meta)->NrOfItems++;
        return 0;
    }

    while(New->Priority <= Current->Priority)
    {
        if(Current->Next != NULL)
        {
            Current = Current->Next;
        }
        else
        {
            Current->Next = New;
            New->Prev = Current;
            (*Meta)->NrOfItems++;
            return 0;
        }
    }

    Current->Prev->Next = New;
    New->Prev = Current->Prev;
    Current->Prev = New;
    New->Next = Current;
    (*Meta)->NrOfItems++;
    return 0;
}
