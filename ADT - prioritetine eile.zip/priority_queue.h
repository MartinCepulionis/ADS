#ifndef PRIORITY_QUEUE_H
#define PRIORITY_QUEUE_H
#include "priority_queue_type.h"

typedef struct Element
{
	prQueue_data_type Data;
	prQueue_priority_type Priority;
	struct Element *Next;
	struct Element *Prev;

} Element;

/*Prioritetines eiles struktura*/
typedef struct
{
	int NrOfItems;
	struct Element *Head;

} PrQueue;

typedef PrQueue* PriorityQueue;

PrQueue* create(int*); /* Funkcija sukurianti tuscia prioritetine eile (Error = 1 - neimanoma sukurti naujos prioritetines eiles) */

 /* Funkcija sujungianti dvi prior. eiles i viena (Error = 1 - maziausiai viena is ju yra tuscia, negalima sujungti)*/

int isEmpty(PriorityQueue); /* Funkcija patikrinanti ar prior. eile yra tuscia (Error =  0 - tuscia, 1 - ne tuscia, 2 - neegzistoja) */

int isFull(PriorityQueue); /* Funkcija patikrinanti ar prior.eile yra pilna (Error = 1 - full, 0 - not full */

int insert(PriorityQueue*, prQueue_data_type ,prQueue_priority_type ); /* Funkcija idedanti elementa i prioritetine eile (Error = 1 - eile neegzistoja, 2 - naujas elementas negali but sukurtas)*/

int destroy(PriorityQueue*); /* Funkcija pasalinanti eile (Error = 1 - eile neegzistoja) */

int removeElement(PriorityQueue*, prQueue_data_type*, prQueue_priority_type*);/*(Error = 1 - eile tuscia)*/

int showElement(PriorityQueue, prQueue_data_type*, prQueue_priority_type*);/*(Error = 1 - eile tuscia)*/

#endif /*PRIORITY_QUEUE_H*/
